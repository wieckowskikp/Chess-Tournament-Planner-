package com.chess.tournament.repository;

import com.chess.tournament.model.Match;
import com.chess.tournament.model.Round;
import com.chess.tournament.model.Tournament;
import com.chess.tournament.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public interface MatchRepository extends JpaRepository<Match, Long> {
    List<Match> findByRound(Round round);
    
    @Transactional
    void deleteByRound(Round round);
    
    @Query("SELECT m FROM Match m WHERE m.round.tournament = ?1")
    List<Match> findByTournament(Tournament tournament);
    
    @Query("SELECT m FROM Match m WHERE (m.whitePlayer = ?1 OR m.blackPlayer = ?1) AND m.round.tournament = ?2")
    List<Match> findByPlayerAndTournament(User player, Tournament tournament);
    
    @Query("SELECT m FROM Match m WHERE (m.whitePlayer = ?1 OR m.blackPlayer = ?1) AND m.round = ?2")
    List<Match> findByPlayerAndRound(User player, Round round);
    
    @Query("SELECT m FROM Match m WHERE (m.whitePlayer = ?1 AND m.blackPlayer = ?2) OR (m.whitePlayer = ?2 AND m.blackPlayer = ?1)")
    List<Match> findMatchesBetweenPlayers(User player1, User player2);
    
    @Query("SELECT COUNT(m) > 0 FROM Match m " +
           "WHERE ((m.whitePlayer = ?1 AND m.blackPlayer = ?2) OR (m.whitePlayer = ?2 AND m.blackPlayer = ?1)) " +
           "AND m.round.tournament = ?3")
    boolean havePlayedInTournament(User player1, User player2, Tournament tournament);
} 