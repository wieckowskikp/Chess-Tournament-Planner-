package com.chess.tournament.repository;

import com.chess.tournament.model.Round;
import com.chess.tournament.model.Tournament;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Repository
public interface RoundRepository extends JpaRepository<Round, Long> {
    List<Round> findByTournament(Tournament tournament);
    List<Round> findByTournamentOrderByRoundNumberAsc(Tournament tournament);
    Optional<Round> findByTournamentAndRoundNumber(Tournament tournament, Integer roundNumber);
    
    @Transactional
    void deleteByTournament(Tournament tournament);
} 