package com.chess.tournament.service.impl;

import com.chess.tournament.model.*;
import com.chess.tournament.repository.*;
import com.chess.tournament.service.TournamentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
@Transactional
public class TournamentServiceImpl implements TournamentService {

    private final TournamentRepository tournamentRepository;
    private final TournamentParticipantRepository participantRepository;
    private final RoundRepository roundRepository;
    private final MatchRepository matchRepository;
    private final PlayerScoreRepository playerScoreRepository;
    private final UserRepository userRepository;

    @Autowired
    public TournamentServiceImpl(TournamentRepository tournamentRepository,
                                TournamentParticipantRepository participantRepository,
                                RoundRepository roundRepository,
                                MatchRepository matchRepository,
                                PlayerScoreRepository playerScoreRepository,
                                UserRepository userRepository) {
        this.tournamentRepository = tournamentRepository;
        this.participantRepository = participantRepository;
        this.roundRepository = roundRepository;
        this.matchRepository = matchRepository;
        this.playerScoreRepository = playerScoreRepository;
        this.userRepository = userRepository;
    }

    @Override
    public List<Tournament> getAllTournaments() {
        return tournamentRepository.findAll();
    }

    @Override
    public Optional<Tournament> getTournamentById(Long id) {
        return tournamentRepository.findById(id);
    }

    @Override
    public Tournament saveTournament(Tournament tournament) {
        return tournamentRepository.save(tournament);
    }

    @Override
    @Transactional
    public void deleteTournament(Long id) {
        Optional<Tournament> tournamentOpt = tournamentRepository.findById(id);
        if (tournamentOpt.isPresent()) {
            Tournament tournament = tournamentOpt.get();
            
            // Delete player scores
            playerScoreRepository.deleteByTournament(tournament);
            
            // Delete all matches for all rounds
            List<Round> rounds = roundRepository.findByTournament(tournament);
            for (Round round : rounds) {
                matchRepository.deleteByRound(round);
            }
            
            // Delete rounds
            roundRepository.deleteByTournament(tournament);
            
            // Delete participants
            participantRepository.deleteByTournament(tournament);
            
            // Finally delete the tournament
            tournamentRepository.deleteById(id);
        }
    }

    @Override
    public boolean addParticipant(Long tournamentId, User user) {
        Optional<Tournament> tournamentOpt = tournamentRepository.findById(tournamentId);
        
        if (!tournamentOpt.isPresent()) {
            return false;
        }
        
        Tournament tournament = tournamentOpt.get();
        
        // Don't allow adding participants to started tournaments
        if (tournament.isStarted()) {
            return false;
        }
        
        // Check if user is already enrolled
        if (participantRepository.existsByTournamentAndUser(tournament, user)) {
            return false; // User is already enrolled
        }
        
        // Create new tournament participant
        TournamentParticipant participant = new TournamentParticipant();
        participant.setTournament(tournament);
        participant.setUser(user);
        
        participantRepository.save(participant);
        return true;
    }

    @Override
    public boolean removeParticipant(Long tournamentId, User user) {
        Optional<Tournament> tournamentOpt = tournamentRepository.findById(tournamentId);
        if (!tournamentOpt.isPresent()) {
            return false;
        }
        
        Tournament tournament = tournamentOpt.get();
        
        // Don't allow removing participants from started tournaments
        if (tournament.isStarted()) {
            return false;
        }
        
        // Find the participant entry
        Optional<TournamentParticipant> participantOpt = 
            participantRepository.findByTournamentAndUser(tournament, user);
        
        if (!participantOpt.isPresent()) {
            return false;
        }
        
        // Remove the participant
        participantRepository.delete(participantOpt.get());
        return true;
    }

    @Override
    public boolean isUserEnrolled(Long tournamentId, User user) {
        Optional<Tournament> tournamentOpt = tournamentRepository.findById(tournamentId);
        if (!tournamentOpt.isPresent()) {
            return false;
        }
        
        return participantRepository.existsByTournamentAndUser(tournamentOpt.get(), user);
    }

    @Override
    public List<User> getTournamentParticipants(Long tournamentId) {
        Optional<Tournament> tournamentOpt = tournamentRepository.findById(tournamentId);
        if (!tournamentOpt.isPresent()) {
            return List.of();
        }
        
        Tournament tournament = tournamentOpt.get();
        return participantRepository.findByTournament(tournament)
                .stream()
                .map(TournamentParticipant::getUser)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public boolean startTournament(Long tournamentId) {
        Optional<Tournament> tournamentOpt = tournamentRepository.findById(tournamentId);
        if (!tournamentOpt.isPresent()) {
            return false;
        }
        
        Tournament tournament = tournamentOpt.get();
        
        // Cannot start a tournament that's already started or completed
        if (tournament.isStarted() || tournament.isCompleted()) {
            return false;
        }
        
        // Check if there are at least 2 participants
        List<User> participants = getTournamentParticipants(tournamentId);
        if (participants.size() < 2) {
            return false;
        }
        
        // Set tournament status to IN_PROGRESS
        tournament.setStatus(Tournament.Status.IN_PROGRESS);
        tournament.setCurrentRound(1);
        
        // Calculate total rounds - Swiss system uses log2(N) rounds where N is number of participants
        int participantCount = participants.size();
        int totalRounds = (int) Math.ceil(Math.log(participantCount) / Math.log(2));
        tournament.setTotalRounds(totalRounds);
        tournamentRepository.save(tournament);
        
        // Initialize player scores for all participants
        for (User participant : participants) {
            PlayerScore playerScore = new PlayerScore();
            playerScore.setTournament(tournament);
            playerScore.setPlayer(participant);
            playerScoreRepository.save(playerScore);
        }
        
        // Create first round with pairings
        createNextRound(tournament);
        
        return true;
    }

    @Override
    public boolean isLastRound(Long tournamentId) {
        Optional<Tournament> tournamentOpt = tournamentRepository.findById(tournamentId);
        if (!tournamentOpt.isPresent()) {
            return false;
        }
        
        Tournament tournament = tournamentOpt.get();
        return tournament.getCurrentRound() != null && 
               tournament.getTotalRounds() != null && 
               tournament.getCurrentRound().equals(tournament.getTotalRounds());
    }

    @Override
    public Round getCurrentRound(Long tournamentId) {
        Optional<Tournament> tournamentOpt = tournamentRepository.findById(tournamentId);
        if (!tournamentOpt.isPresent() || !tournamentOpt.get().isStarted()) {
            return null;
        }
        
        Tournament tournament = tournamentOpt.get();
        Integer currentRoundNumber = tournament.getCurrentRound();
        
        if (currentRoundNumber == null || currentRoundNumber <= 0) {
            return null;
        }
        
        Optional<Round> roundOpt = roundRepository.findByTournamentAndRoundNumber(tournament, currentRoundNumber);
        return roundOpt.orElse(null);
    }

    @Override
    public List<Round> getTournamentRounds(Long tournamentId) {
        Optional<Tournament> tournamentOpt = tournamentRepository.findById(tournamentId);
        if (!tournamentOpt.isPresent()) {
            return List.of();
        }
        
        Tournament tournament = tournamentOpt.get();
        return roundRepository.findByTournamentOrderByRoundNumberAsc(tournament);
    }

    @Override
    public List<Match> getRoundMatches(Long roundId) {
        Optional<Round> roundOpt = roundRepository.findById(roundId);
        if (!roundOpt.isPresent()) {
            return List.of();
        }
        
        return matchRepository.findByRound(roundOpt.get());
    }

    @Override
    @Transactional
    public boolean updateMatchResult(Long matchId, Match.Result result) {
        Optional<Match> matchOpt = matchRepository.findById(matchId);
        if (!matchOpt.isPresent()) {
            return false;
        }
        
        Match match = matchOpt.get();
        
        // Only update pending matches
        if (match.getResult() != Match.Result.PENDING) {
            return false;
        }
        
        match.setResult(result);
        match.setCompletedAt(new Date());
        matchRepository.save(match);
        
        // Update player scores
        updatePlayerScores(match);
        
        // Check if round is complete and update round status
        Round round = match.getRound();
        boolean isRoundComplete = isRoundComplete(round);
        if (isRoundComplete) {
            round.setCompleted(true);
            roundRepository.save(round);
            
            // Check if this is the last round and all matches are complete
            Tournament tournament = round.getTournament();
            if (isLastRound(tournament.getId()) && isRoundComplete) {
                // Complete the tournament
                completeTournament(tournament.getId());
            }
        }
        
        return true;
    }
    
    private void updatePlayerScores(Match match) {
        Tournament tournament = match.getRound().getTournament();
        // If this is a bye (white and black are the same), only update once
        if (match.getWhitePlayer().getId().equals(match.getBlackPlayer().getId())) {
            Optional<PlayerScore> scoreOpt = playerScoreRepository.findByTournamentAndPlayer(
                tournament, match.getWhitePlayer());
            if (scoreOpt.isPresent()) {
                PlayerScore score = scoreOpt.get();
                score.updateScore(match);
                playerScoreRepository.save(score);
            }
            return;
        }
        // Update white player score
        Optional<PlayerScore> whiteScoreOpt = playerScoreRepository.findByTournamentAndPlayer(
            tournament, match.getWhitePlayer());
        if (whiteScoreOpt.isPresent()) {
            PlayerScore whiteScore = whiteScoreOpt.get();
            whiteScore.updateScore(match);
            playerScoreRepository.save(whiteScore);
        }
        // Update black player score
        Optional<PlayerScore> blackScoreOpt = playerScoreRepository.findByTournamentAndPlayer(
            tournament, match.getBlackPlayer());
        if (blackScoreOpt.isPresent()) {
            PlayerScore blackScore = blackScoreOpt.get();
            blackScore.updateScore(match);
            playerScoreRepository.save(blackScore);
        }
    }

    @Override
    @Transactional
    public boolean advanceToNextRound(Long tournamentId) {
        Optional<Tournament> tournamentOpt = tournamentRepository.findById(tournamentId);
        if (!tournamentOpt.isPresent()) {
            return false;
        }
        
        Tournament tournament = tournamentOpt.get();
        
        // Check if can advance to next round
        if (!tournament.canAdvanceToNextRound()) {
            return false;
        }
        
        // Check if this is the last round
        if (isLastRound(tournamentId)) {
            // If last round, complete the tournament instead of creating a new round
            return completeTournament(tournamentId);
        }
        
        // Increment round number
        tournament.setCurrentRound(tournament.getCurrentRound() + 1);
        tournamentRepository.save(tournament);
        
        // Create next round with pairings
        createNextRound(tournament);
        
        return true;
    }
    
    @Transactional
    protected Round createNextRound(Tournament tournament) {
        // Create new round
        Round round = new Round();
        round.setTournament(tournament);
        round.setRoundNumber(tournament.getCurrentRound());
        round = roundRepository.save(round);
        
        // Get participants and their scores
        Map<User, PlayerScore> playerScores = getPlayerScores(tournament.getId());
        List<User> participants = new ArrayList<>(playerScores.keySet());
        
        // Sort participants by score for pairing
        participants.sort((p1, p2) -> {
            Double score1 = playerScores.get(p1).getScore();
            Double score2 = playerScores.get(p2).getScore();
            // Sort by descending score
            int scoreCompare = score2.compareTo(score1);
            if (scoreCompare != 0) {
                return scoreCompare;
            }
            // If scores are equal, sort by ascending ELO (helps with stable pairings)
            return p1.getElo().compareTo(p2.getElo());
        });
        
        // Create matches using Swiss system pairing
        createSwissPairings(round, participants, tournament);
        
        return round;
    }
    
    @Transactional
    protected void createSwissPairings(Round round, List<User> sortedPlayers, Tournament tournament) {
        Map<User, Boolean> paired = new HashMap<>();
        List<Match> matches = new ArrayList<>();
        
        // First round is paired randomly or by ELO
        if (round.getRoundNumber() == 1) {
            createFirstRoundPairings(round, sortedPlayers);
            return;
        }
        
        // For subsequent rounds, pair players by score groups
        Map<Double, List<User>> scoreGroups = groupPlayersByScore(tournament.getId(), sortedPlayers);
        
        // Process each score group
        for (Double score : scoreGroups.keySet().stream().sorted(Collections.reverseOrder()).collect(Collectors.toList())) {
            List<User> playersInGroup = scoreGroups.get(score);
            
            // If odd number of players, find the best player from lower score group to pair with
            if (playersInGroup.size() % 2 != 0) {
                User unpairedPlayer = playersInGroup.get(playersInGroup.size() - 1);
                playersInGroup.remove(unpairedPlayer);
                
                // Try to find opponent from next score group
                User opponent = findOpponentFromLowerScoreGroup(unpairedPlayer, scoreGroups, score, paired, tournament);
                if (opponent != null) {
                    createMatch(round, unpairedPlayer, opponent);
                    paired.put(unpairedPlayer, true);
                    paired.put(opponent, true);
                } else {
                    // Add back to group if no opponent found
                    playersInGroup.add(unpairedPlayer);
                }
            }
            
            // Pair remaining players in the score group
            for (int i = 0; i < playersInGroup.size(); i++) {
                User player = playersInGroup.get(i);
                
                if (paired.containsKey(player)) continue;
                paired.put(player, true);
                
                User opponent = null;
                for (int j = i + 1; j < playersInGroup.size(); j++) {
                    User potentialOpponent = playersInGroup.get(j);
                    
                    if (!paired.containsKey(potentialOpponent) && 
                        !havePlayedBefore(player, potentialOpponent, tournament)) {
                        opponent = potentialOpponent;
                        break;
                    }
                }
                
                // If no valid opponent found, pick the first available one (even if they played before)
                if (opponent == null) {
                    for (int j = i + 1; j < playersInGroup.size(); j++) {
                        if (!paired.containsKey(playersInGroup.get(j))) {
                            opponent = playersInGroup.get(j);
                            break;
                        }
                    }
                }
                
                if (opponent != null) {
                    paired.put(opponent, true);
                    createMatch(round, player, opponent);
                }
            }
        }
        
        // Handle any unpaired players (should be at most 1 in rare cases)
        List<User> unpairedPlayers = sortedPlayers.stream()
            .filter(p -> !paired.containsKey(p))
            .collect(Collectors.toList());
        
        if (unpairedPlayers.size() == 1) {
            // Assign a bye (free win) if there's exactly one unpaired player
            User unpairedPlayer = unpairedPlayers.get(0);
            
            // Create a "bye" match where player competes against themselves
            Match byeMatch = new Match();
            byeMatch.setRound(round);
            byeMatch.setWhitePlayer(unpairedPlayer);
            byeMatch.setBlackPlayer(unpairedPlayer);  // Using same player as placeholder
            byeMatch.setResult(Match.Result.WHITE_WIN); // Automatic win
            byeMatch.setCompletedAt(new Date());
            matchRepository.save(byeMatch);
            
            // Update player score for the bye
            updatePlayerScores(byeMatch);
        }
        else if (unpairedPlayers.size() > 1) {
            // Pair any remaining players with each other (shouldn't happen in proper Swiss, but as a fallback)
            for (int i = 0; i < unpairedPlayers.size() - 1; i += 2) {
                User player1 = unpairedPlayers.get(i);
                User player2 = unpairedPlayers.get(i + 1);
                createMatch(round, player1, player2);
            }
        }
    }
    
    private void createFirstRoundPairings(Round round, List<User> players) {
        // Sort by ELO rating
        players.sort(Comparator.comparing(User::getElo).reversed());
        
        // Split list in half and pair top with bottom
        int half = players.size() / 2;
        for (int i = 0; i < half; i++) {
            User topHalfPlayer = players.get(i);
            User bottomHalfPlayer = players.get(i + half);
            createMatch(round, topHalfPlayer, bottomHalfPlayer);
        }
        
        // If odd number of players, handle the remaining player
        if (players.size() % 2 != 0) {
            User unpairedPlayer = players.get(players.size() - 1);
            
            // Create a "bye" match where player competes against themselves
            Match byeMatch = new Match();
            byeMatch.setRound(round);
            byeMatch.setWhitePlayer(unpairedPlayer);
            byeMatch.setBlackPlayer(unpairedPlayer);  // Using same player as placeholder
            byeMatch.setResult(Match.Result.WHITE_WIN); // Automatic win
            byeMatch.setCompletedAt(new Date());
            matchRepository.save(byeMatch);
            
            // Update player score for the bye
            updatePlayerScores(byeMatch);
        }
    }
    
    private void createMatch(Round round, User player1, User player2) {
        // Randomly assign white/black
        boolean player1IsWhite = Math.random() < 0.5;
        Match match = new Match();
        match.setRound(round);
        match.setWhitePlayer(player1IsWhite ? player1 : player2);
        match.setBlackPlayer(player1IsWhite ? player2 : player1);
        match.setResult(Match.Result.PENDING);
        matchRepository.save(match);
    }
    
    private Map<Double, List<User>> groupPlayersByScore(Long tournamentId, List<User> players) {
        Map<Double, List<User>> scoreGroups = new HashMap<>();
        Map<User, PlayerScore> playerScores = getPlayerScores(tournamentId);
        
        for (User player : players) {
            PlayerScore score = playerScores.get(player);
            if (score == null) continue;
            
            Double playerScore = score.getScore();
            if (!scoreGroups.containsKey(playerScore)) {
                scoreGroups.put(playerScore, new ArrayList<>());
            }
            scoreGroups.get(playerScore).add(player);
        }
        
        return scoreGroups;
    }
    
    private User findOpponentFromLowerScoreGroup(User player, Map<Double, List<User>> scoreGroups, 
                                              Double currentScore, Map<User, Boolean> paired, 
                                              Tournament tournament) {
        List<Double> lowerScores = scoreGroups.keySet().stream()
            .filter(s -> s < currentScore)
            .sorted(Collections.reverseOrder())
            .collect(Collectors.toList());
        
        for (Double score : lowerScores) {
            List<User> playersInGroup = scoreGroups.get(score);
            for (User potentialOpponent : playersInGroup) {
                if (!paired.containsKey(potentialOpponent) && 
                    !havePlayedBefore(player, potentialOpponent, tournament)) {
                    
                    // Move player to current group
                    playersInGroup.remove(potentialOpponent);
                    
                    return potentialOpponent;
                }
            }
        }
        
        return null;
    }
    
    private boolean havePlayedBefore(User player1, User player2, Tournament tournament) {
        return matchRepository.havePlayedInTournament(player1, player2, tournament);
    }

    @Override
    public List<PlayerScore> getTournamentStandings(Long tournamentId) {
        Optional<Tournament> tournamentOpt = tournamentRepository.findById(tournamentId);
        if (!tournamentOpt.isPresent()) {
            return List.of();
        }
        
        return playerScoreRepository.findByTournamentOrderByScoreDesc(tournamentOpt.get());
    }

    @Override
    public Map<User, PlayerScore> getPlayerScores(Long tournamentId) {
        List<PlayerScore> scores = getTournamentStandings(tournamentId);
        Map<User, PlayerScore> playerScores = new HashMap<>();
        
        scores.forEach(score -> playerScores.put(score.getPlayer(), score));
        return playerScores;
    }

    @Override
    public Optional<User> getTournamentWinner(Long tournamentId) {
        Optional<Tournament> tournamentOpt = tournamentRepository.findById(tournamentId);
        if (!tournamentOpt.isPresent() || !tournamentOpt.get().isCompleted()) {
            return Optional.empty();
        }
        
        Tournament tournament = tournamentOpt.get();
        if (tournament.getWinner() != null) {
            return Optional.of(tournament.getWinner());
        }
        
        List<PlayerScore> standings = getTournamentStandings(tournamentId);
        if (!standings.isEmpty()) {
            return Optional.of(standings.get(0).getPlayer());
        }
        
        return Optional.empty();
    }

    @Override
    public boolean isRoundComplete(Long roundId) {
        Optional<Round> roundOpt = roundRepository.findById(roundId);
        return roundOpt.map(this::isRoundComplete).orElse(false);
    }

    @Override
    public boolean isRoundComplete(Round round) {
        List<Match> matches = matchRepository.findByRound(round);
        if (matches.isEmpty()) {
            return false;
        }
        
        return matches.stream().allMatch(match -> match.getResult() != Match.Result.PENDING);
    }

    @Override
    @Transactional
    public boolean completeTournament(Long tournamentId) {
        Optional<Tournament> tournamentOpt = tournamentRepository.findById(tournamentId);
        if (!tournamentOpt.isPresent() || tournamentOpt.get().isCompleted()) {
            return false;
        }
        
        Tournament tournament = tournamentOpt.get();
        
        // Check if all rounds are complete
        List<Round> rounds = roundRepository.findByTournament(tournament);
        boolean allRoundsComplete = rounds.stream().allMatch(Round::getCompleted);
        
        if (!allRoundsComplete) {
            return false;
        }
        
        // Find tournament winner (player with highest score)
        List<PlayerScore> standings = getTournamentStandings(tournamentId);
        if (!standings.isEmpty()) {
            User winner = standings.get(0).getPlayer();
            tournament.setWinner(winner);
        }
        
        // Make sure current round is marked as completed
        Round currentRound = getCurrentRound(tournamentId);
        if (currentRound != null && !currentRound.getCompleted()) {
            currentRound.setCompleted(true);
            roundRepository.save(currentRound);
        }
        
        tournament.setStatus(Tournament.Status.COMPLETED);
        tournament.setCompletedAt(new Date());
        tournamentRepository.save(tournament);
        
        return true;
    }

    @Override
    public Optional<PlayerScore> getPlayerScore(Long tournamentId, User player) {
        Optional<Tournament> tournamentOpt = tournamentRepository.findById(tournamentId);
        if (!tournamentOpt.isPresent()) {
            return Optional.empty();
        }
        
        return playerScoreRepository.findByTournamentAndPlayer(tournamentOpt.get(), player);
    }
} 