package com.chess.tournament.service;

import com.chess.tournament.model.*;

import java.util.List;
import java.util.Map;
import java.util.Optional;

public interface TournamentService {
    // Tournament management
    List<Tournament> getAllTournaments();
    Optional<Tournament> getTournamentById(Long id);
    Tournament saveTournament(Tournament tournament);
    void deleteTournament(Long id);
    
    // Participant management
    boolean addParticipant(Long tournamentId, User user);
    boolean removeParticipant(Long tournamentId, User user);
    boolean isUserEnrolled(Long tournamentId, User user);
    List<User> getTournamentParticipants(Long tournamentId);
    
    // Tournament rounds and matches
    boolean startTournament(Long tournamentId);
    boolean isLastRound(Long tournamentId);
    Round getCurrentRound(Long tournamentId);
    List<Round> getTournamentRounds(Long tournamentId);
    List<Match> getRoundMatches(Long roundId);
    
    // Match results
    boolean updateMatchResult(Long matchId, Match.Result result);
    boolean advanceToNextRound(Long tournamentId);
    
    // Tournament standings
    List<PlayerScore> getTournamentStandings(Long tournamentId);
    Map<User, PlayerScore> getPlayerScores(Long tournamentId);
    Optional<PlayerScore> getPlayerScore(Long tournamentId, User player);
    Optional<User> getTournamentWinner(Long tournamentId);
    boolean isRoundComplete(Long roundId);
    boolean isRoundComplete(Round round);
    boolean completeTournament(Long tournamentId);
} 