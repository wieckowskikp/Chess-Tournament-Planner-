# Chess Tournament Planner - Dokumentacja Projektu

## Przegląd projektu

Chess Tournament Planner to aplikacja webowa do zarządzania turniejami szachowymi. Umożliwia organizowanie turniejów w systemie szwajcarskim, zarządzanie uczestnikami oraz śledzenie wyników i rankingów. Aplikacja oferuje intuicyjny interfejs dla graczy i zaawansowane narzędzia dla administratorów.

## Główne funkcjonalności

### Dla graczy:
- Rejestracja i logowanie do systemu
- Przeglądanie dostępnych turniejów
- Dołączanie do turniejów przed ich rozpoczęciem
- Śledzenie własnych wyników i pozycji w rankingach
- Aktualizacja danych profilu

### Dla administratorów:
- Zarządzanie użytkownikami i ich rankingami ELO
- Tworzenie nowych turniejów z konfiguracją
- Dodawanie i usuwanie uczestników z turniejów
- Wprowadzanie wyników meczów
- Monitorowanie postępów wszystkich turniejów

### Automatyzacja:
- Automatyczne kojarzenie par graczy według systemu szwajcarskiego
- Obliczanie i aktualizacja wyników po każdym meczu
- Zarządzanie rundami i przechodzenie do kolejnych etapów
- Obsługa nieparzystej liczby graczy (automatyczne "bye")

## Technologie

### Backend:
- Java 17
- Spring Boot 2.7.14
- Spring Security (bezpieczeństwo)
- Spring Data JPA (dostęp do bazy danych)
- Hibernate (mapowanie obiektowo-relacyjne)
- MySQL 8.0 (baza danych)
- Maven (zarządzanie projektem)
- Lombok (redukcja kodu)

### Frontend:
- Thymeleaf (szablony HTML)
- HTML5/CSS3
- JavaScript
- Responsywny design

### Bezpieczeństwo:
- BCrypt (hashowanie haseł)
- Spring Security (autoryzacja)
- Zarządzanie sesjami użytkowników

## Architektura aplikacji

Aplikacja wykorzystuje wzorzec MVC (Model-View-Controller) z dodatkową warstwą serwisową:

- **Controllers** - obsługują żądania HTTP i kierują do odpowiednich serwisów
- **Services** - zawierają logikę biznesową (turnieje, użytkownicy, kojarzenie par)
- **Repositories** - zapewniają dostęp do bazy danych
- **Models** - reprezentują encje w bazie danych (Turniej, Użytkownik, Mecz, Runda)
- **Views** - szablony Thymeleaf wyświetlane użytkownikom

## Role użytkowników

### Użytkownik (USER)
Może przeglądać turnieje, dołączać do nich, przeglądać własny profil i historię, aktualizować dane profilu. Nie ma dostępu do funkcji administracyjnych.

### Administrator (ADMIN)
Ma wszystkie uprawnienia użytkownika plus dostęp do panelu administracyjnego. Może zarządzać użytkownikami, tworzyć i prowadzić turnieje, wprowadzać wyniki meczów, przechodzić do kolejnych rund.

## API Endpoints

### Publiczne:
- Strona główna, rejestracja, logowanie, zasoby statyczne

### Dla zalogowanych użytkowników:
- Panel główny, lista turniejów, profil, dołączanie do turniejów, moje turnieje

### Dla administratorów:
- Panel administracyjny, zarządzanie użytkownikami, tworzenie turniejów, prowadzenie rozgrywek

## Algorytm kojarzenia par w systemie szwajcarskim

### Pierwsza runda:
Gracze są sortowani według rankingów ELO i kojarzeni w parach: najlepszy z najgorszym, drugi z przedostatnim itd.

### Kolejne rundy:
1. Gracze są grupowani według aktualnych wyników
2. W każdej grupie wynikowej gracze są kojarzeni ze sobą
3. Unika się powtórzeń meczów (gracze nie grają ze sobą więcej niż raz)
4. Jeśli liczba graczy w grupie jest nieparzysta, jeden gracz otrzymuje "bye" (wolny punkt)
5. Kolory (biały/czarny) są przydzielane losowo

### Obsługa specjalnych przypadków:
- Nieparzysta liczba graczy - automatyczne "bye"
- Brak możliwych par bez powtórzeń - dopuszczenie powtórzenia
- Równe wyniki - sortowanie według rankingów ELO

## System rankingowy ELO

### Zasady:
- Każdy nowy użytkownik otrzymuje ranking 1200 punktów
- Ranking odzwierciedla względną siłę gracza
- Używany do kojarzenia par w pierwszej rundzie
- Służy jako kryterium sortowania przy równych wynikach

### Uwaga:
Aktualna implementacja nie zawiera algorytmu aktualizacji rankingów ELO po meczach. Rankingi są używane tylko do kojarzenia par i sortowania.

## Struktura folderów i plików

```
src/main/java/com/chess/tournament/
├── config/          # Konfiguracja (bezpieczeństwo, inicjalizacja)
├── controller/      # Kontrolery (główny, admin, autoryzacja)
├── model/          # Encje (Turniej, Użytkownik, Mecz, Runda, Wynik)
├── repository/     # Repozytoria danych
├── service/        # Logika biznesowa
│   └── impl/       # Implementacje serwisów

src/main/resources/
├── application.properties  # Konfiguracja aplikacji
├── schema.sql             # Struktura bazy danych
├── static/                # Zasoby statyczne (CSS, JS)
└── templates/             # Szablony Thymeleaf
    ├── admin/             # Panel administracyjny
    ├── auth/              # Logowanie/rejestracja
    └── layout/            # Podstawowy layout
```

## Uruchomienie aplikacji

### Wymagania:
- Java 17+
- Maven 3.6+
- MySQL 8.0+
- Przeglądarka internetowa

### Konfiguracja:
1. Utwórz bazę danych MySQL
2. Zaktualizuj dane połączenia w `application.properties`
3. Uruchom aplikację przez Maven: `mvn spring-boot:run`
4. Otwórz przeglądarkę: http://localhost:8080

### Dostęp:
- Aplikacja: http://localhost:8080
ADMIN:
login: admin
hasło: admin

UŻYTKOWNICY (stworzeni 4 tymczasowi):
login: player1
hasło: player1

login: player2
hasło: player2

login: player3
hasło: player3

login: player4
hasło: player4

BAZA:
spring.datasource.username=ait127897
spring.datasource.password=KW127897

## Bezpieczeństwo

### Implementowane mechanizmy:
- Hashowanie haseł (BCrypt)
- Autoryzacja oparta na rolach
- Ochrona endpointów administracyjnych
- Zarządzanie sesjami użytkowników
- Bezpieczne przekierowania

### Ochrona endpointów:
- Publiczne: strona główna, rejestracja, logowanie
- Użytkownicy: wszystkie funkcje po zalogowaniu
- Administratorzy: panel administracyjny

### Zalecenia produkcyjne:
- Włączenie HTTPS
- Silne hasła do bazy danych
- Regularne kopie zapasowe
- Monitoring prób logowania
- Aktualizacje bezpieczeństwa

