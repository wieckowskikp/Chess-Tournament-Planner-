package com.chess.tournament.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.EqualsAndHashCode;

import javax.persistence.*;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "tournaments")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString(exclude = {"participants", "rounds", "winner"})
@EqualsAndHashCode(exclude = {"participants", "rounds", "winner"})
public class Tournament {
    
    public enum Status {
        CREATED,       // Tournament created but not started
        IN_PROGRESS,   // Tournament is ongoing
        COMPLETED      // Tournament is finished
    }
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false)
    private String name;
    
    @Column
    private String description;
    
    @Column(name = "current_round")
    private Integer currentRound = 0;
    
    @Column(name = "total_rounds")
    private Integer totalRounds;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = true)
    private Status status = Status.CREATED;
    
    @Column(name = "created_at")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;
    
    @Column(name = "completed_at")
    @Temporal(TemporalType.TIMESTAMP)
    private Date completedAt;
    
    @OneToMany(mappedBy = "tournament", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<TournamentParticipant> participants = new HashSet<>();
    
    @OneToMany(mappedBy = "tournament", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<Round> rounds = new HashSet<>();
    
    @ManyToOne
    @JoinColumn(name = "winner_id")
    private User winner;
    
    @PrePersist
    protected void onCreate() {
        this.createdAt = new Date();
    }
    
    @Transient
    public boolean isStarted() {
        return status != Status.CREATED;
    }
    
    @Transient
    public boolean isCompleted() {
        return status == Status.COMPLETED;
    }
    
    @Transient
    public boolean canAdvanceToNextRound() {
        return status == Status.IN_PROGRESS && 
               (totalRounds == null || currentRound < totalRounds) && 
               getCurrentRoundObj() != null && 
               getCurrentRoundObj().getCompleted();
    }
    
    @Transient
    public Round getCurrentRoundObj() {
        if (currentRound == null || currentRound <= 0) {
            return null;
        }
        
        for (Round round : rounds) {
            if (round.getRoundNumber().equals(currentRound)) {
                return round;
            }
        }
        return null;
    }
} 