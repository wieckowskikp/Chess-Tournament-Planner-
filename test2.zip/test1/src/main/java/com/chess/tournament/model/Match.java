package com.chess.tournament.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.EqualsAndHashCode;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "matches")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString(exclude = {"round", "whitePlayer", "blackPlayer"})
@EqualsAndHashCode(exclude = {"round", "whitePlayer", "blackPlayer"})
public class Match {
    
    public enum Result {
        WHITE_WIN,   // White player won
        BLACK_WIN,   // Black player won
        DRAW,        // Draw
        PENDING      // Match not yet completed
    }
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @ManyToOne
    @JoinColumn(name = "round_id", nullable = false)
    private Round round;
    
    @ManyToOne
    @JoinColumn(name = "white_player_id", nullable = false)
    private User whitePlayer;
    
    @ManyToOne
    @JoinColumn(name = "black_player_id", nullable = false)
    private User blackPlayer;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "result", nullable = false)
    private Result result = Result.PENDING;
    
    @Column(name = "created_at")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;
    
    @Column(name = "completed_at")
    @Temporal(TemporalType.TIMESTAMP)
    private Date completedAt;
    
    @PrePersist
    protected void onCreate() {
        this.createdAt = new Date();
    }
    
    // Helper method to get winner (or null if draw or pending)
    @Transient
    public User getWinner() {
        if (result == Result.WHITE_WIN) {
            return whitePlayer;
        } else if (result == Result.BLACK_WIN) {
            return blackPlayer;
        }
        return null;
    }
    
    // Helper method to get loser (or null if draw or pending)
    @Transient
    public User getLoser() {
        if (result == Result.WHITE_WIN) {
            return blackPlayer;
        } else if (result == Result.BLACK_WIN) {
            return whitePlayer;
        }
        return null;
    }
    
    // Helper method to check if the match involves a specific player
    @Transient
    public boolean involvesPlayer(User player) {
        return whitePlayer.getId().equals(player.getId()) || blackPlayer.getId().equals(player.getId());
    }
    
    // Helper method to check if two players have played against each other
    @Transient
    public boolean isMatchBetween(User player1, User player2) {
        return (whitePlayer.getId().equals(player1.getId()) && blackPlayer.getId().equals(player2.getId())) ||
               (whitePlayer.getId().equals(player2.getId()) && blackPlayer.getId().equals(player1.getId()));
    }
} 