package com.chess.tournament.repository;

import com.chess.tournament.model.Tournament;
import com.chess.tournament.model.TournamentParticipant;
import com.chess.tournament.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Repository
public interface TournamentParticipantRepository extends JpaRepository<TournamentParticipant, Long> {
    List<TournamentParticipant> findByTournament(Tournament tournament);
    List<TournamentParticipant> findByUser(User user);
    Optional<TournamentParticipant> findByTournamentAndUser(Tournament tournament, User user);
    boolean existsByTournamentAndUser(Tournament tournament, User user);
    
    @Transactional
    void deleteByTournament(Tournament tournament);
} 