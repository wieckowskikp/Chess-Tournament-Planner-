package com.chess.tournament.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.EqualsAndHashCode;

import javax.persistence.*;

@Entity
@Table(name = "player_scores", uniqueConstraints = {
    @UniqueConstraint(columnNames = {"tournament_id", "player_id"})
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString(exclude = {"tournament", "player"})
@EqualsAndHashCode(exclude = {"tournament", "player"})
public class PlayerScore {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @ManyToOne
    @JoinColumn(name = "tournament_id", nullable = false)
    private Tournament tournament;
    
    @ManyToOne
    @JoinColumn(name = "player_id", nullable = false)
    private User player;
    
    @Column(name = "score", nullable = false)
    private Double score = 0.0;
    
    @Column(name = "matches_played", nullable = false)
    private Integer matchesPlayed = 0;
    
    @Column(name = "wins", nullable = false)
    private Integer wins = 0;
    
    @Column(name = "draws", nullable = false)
    private Integer draws = 0;
    
    @Column(name = "losses", nullable = false)
    private Integer losses = 0;
    
    // Update score based on match result
    public void updateScore(Match match) {
        if (match.getResult() == Match.Result.PENDING) {
            return; // Don't update if match is pending
        }
        
        matchesPlayed++;
        
        if (match.getResult() == Match.Result.DRAW) {
            score += 0.5;
            draws++;
        } 
        else if ((match.getWhitePlayer().getId().equals(player.getId()) && match.getResult() == Match.Result.WHITE_WIN) ||
                (match.getBlackPlayer().getId().equals(player.getId()) && match.getResult() == Match.Result.BLACK_WIN)) {
            score += 1.0;
            wins++;
        }
        else {
            losses++;
        }
    }
} 