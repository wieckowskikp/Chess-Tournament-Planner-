package com.chess.tournament.repository;

import com.chess.tournament.model.PlayerScore;
import com.chess.tournament.model.Tournament;
import com.chess.tournament.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Repository
public interface PlayerScoreRepository extends JpaRepository<PlayerScore, Long> {
    List<PlayerScore> findByTournamentOrderByScoreDesc(Tournament tournament);
    Optional<PlayerScore> findByTournamentAndPlayer(Tournament tournament, User player);
    boolean existsByTournamentAndPlayer(Tournament tournament, User player);
    
    @Transactional
    void deleteByTournament(Tournament tournament);
} 