package com.chess.tournament.controller;

import com.chess.tournament.model.User;
import com.chess.tournament.model.Tournament;
import com.chess.tournament.model.PlayerScore;
import com.chess.tournament.model.Round;
import com.chess.tournament.model.Match;
import com.chess.tournament.repository.TournamentRepository;
import com.chess.tournament.repository.UserRepository;
import com.chess.tournament.service.TournamentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Controller
public class MainController {

    private final TournamentRepository tournamentRepository;
    private final UserRepository userRepository;
    private final TournamentService tournamentService;
    
    @Autowired
    public MainController(TournamentRepository tournamentRepository, 
                          UserRepository userRepository,
                          TournamentService tournamentService) {
        this.tournamentRepository = tournamentRepository;
        this.userRepository = userRepository;
        this.tournamentService = tournamentService;
    }

    @GetMapping("/")
    public String index() {
        return "index";
    }

    @GetMapping("/home")
    public String home(Model model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String username = auth.getName();
        model.addAttribute("username", username);
        
        boolean isAdmin = auth.getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));
        model.addAttribute("isAdmin", isAdmin);
        
        return "home";
    }

    @GetMapping("/events")
    public String viewEvents(Model model) {
        model.addAttribute("tournaments", tournamentRepository.findAll());
        
        // Add enrolled status for the current user
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null && auth.isAuthenticated() && !auth.getName().equals("anonymousUser")) {
            String username = auth.getName();
            User user = userRepository.findByUsername(username)
                    .orElseThrow(() -> new IllegalStateException("User not found: " + username));
            
            Map<Long, Boolean> enrollmentStatus = new HashMap<>();
            tournamentRepository.findAll().forEach(tournament -> {
                boolean isEnrolled = tournamentService.isUserEnrolled(tournament.getId(), user);
                enrollmentStatus.put(tournament.getId(), isEnrolled);
            });
            
            model.addAttribute("enrollmentStatus", enrollmentStatus);
        }
        
        return "events";
    }
    
    @PostMapping("/tournaments/{id}/join")
    public String joinTournament(@PathVariable("id") Long tournamentId, 
                                 RedirectAttributes redirectAttributes) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !auth.isAuthenticated() || auth.getName().equals("anonymousUser")) {
            redirectAttributes.addFlashAttribute("error", "You must be logged in to join a tournament");
            return "redirect:/login";
        }
        
        String username = auth.getName();
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new IllegalStateException("User not found: " + username));
        
        boolean success = tournamentService.addParticipant(tournamentId, user);
        
        if (success) {
            redirectAttributes.addFlashAttribute("success", "You have successfully joined the tournament");
        } else {
            redirectAttributes.addFlashAttribute("error", "You are already enrolled in this tournament or it doesn't exist");
        }
        
        return "redirect:/events";
    }
    
    // AJAX endpoint for joining tournament
    @PostMapping("/api/tournaments/{id}/join")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> joinTournamentApi(@PathVariable("id") Long tournamentId) {
        Map<String, Object> response = new HashMap<>();
        
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !auth.isAuthenticated() || auth.getName().equals("anonymousUser")) {
            response.put("success", false);
            response.put("message", "You must be logged in to join a tournament");
            return ResponseEntity.badRequest().body(response);
        }
        
        String username = auth.getName();
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new IllegalStateException("User not found: " + username));
        
        boolean success = tournamentService.addParticipant(tournamentId, user);
        
        response.put("success", success);
        if (success) {
            response.put("message", "You have successfully joined the tournament");
        } else {
            response.put("message", "You are already enrolled in this tournament or it doesn't exist");
        }
        
        return ResponseEntity.ok(response);
    }
    
    @GetMapping("/profile")
    public String showProfile(Model model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String username = auth.getName();
        
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new IllegalStateException("User not found: " + username));
        
        model.addAttribute("user", user);
        
        // Get tournament history and results
        List<Tournament> allTournaments = tournamentRepository.findAll();
        List<Map<String, Object>> tournamentResults = new ArrayList<>();
        
        for (Tournament tournament : allTournaments) {
            if (tournamentService.isUserEnrolled(tournament.getId(), user)) {
                Map<String, Object> result = new HashMap<>();
                result.put("tournament", tournament);
                
                // Get player's score in this tournament
                Optional<PlayerScore> playerScoreOpt = tournamentService.getPlayerScore(tournament.getId(), user);
                
                if (playerScoreOpt.isPresent()) {
                    PlayerScore playerScore = playerScoreOpt.get();
                    result.put("score", playerScore);
                    
                    // Calculate position
                    List<PlayerScore> standings = tournamentService.getTournamentStandings(tournament.getId());
                    int position = 0;
                    for (int i = 0; i < standings.size(); i++) {
                        if (standings.get(i).getPlayer().getId().equals(user.getId())) {
                            position = i + 1; // 1-based position
                            break;
                        }
                    }
                    result.put("position", position);
                }
                
                tournamentResults.add(result);
            }
        }
        
        model.addAttribute("tournamentResults", tournamentResults);
        
        return "profile";
    }
    
    @PostMapping("/profile/update")
    public String updateProfile(@ModelAttribute User userUpdate, RedirectAttributes redirectAttributes) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String username = auth.getName();
        
        User currentUser = userRepository.findByUsername(username)
                .orElseThrow(() -> new IllegalStateException("User not found: " + username));
        
        // Check if email is being changed and is already in use
        if (!currentUser.getEmail().equals(userUpdate.getEmail()) && 
            userRepository.existsByEmail(userUpdate.getEmail())) {
            redirectAttributes.addFlashAttribute("error", "Email already in use by another account");
            return "redirect:/profile";
        }
        
        // Update user details
        currentUser.setFirstName(userUpdate.getFirstName());
        currentUser.setLastName(userUpdate.getLastName());
        currentUser.setEmail(userUpdate.getEmail());
        
        userRepository.save(currentUser);
        redirectAttributes.addFlashAttribute("success", "Profile updated successfully");
        return "redirect:/profile";
    }

    @GetMapping("/admin")
    public String adminDashboard() {
        return "admin/dashboard";
    }

    @GetMapping("/tournaments/{id}/details")
    public String viewTournamentDetails(@PathVariable("id") Long tournamentId, Model model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        boolean isAuthenticated = auth != null && auth.isAuthenticated() && !auth.getName().equals("anonymousUser");
        
        // Check if user is admin, redirect to admin tournament details page
        boolean isAdmin = auth.getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));
        if (isAdmin) {
            return "redirect:/admin/tournaments/" + tournamentId + "/details";
        }
        
        // Get tournament
        Optional<Tournament> tournamentOpt = tournamentService.getTournamentById(tournamentId);
        if (!tournamentOpt.isPresent()) {
            return "redirect:/events";
        }
        
        Tournament tournament = tournamentOpt.get();
        model.addAttribute("tournament", tournament);
        
        // Get participants
        List<User> participants = tournamentService.getTournamentParticipants(tournamentId);
        model.addAttribute("participants", participants);
        
        // Get tournament standings
        List<PlayerScore> standings = tournamentService.getTournamentStandings(tournamentId);
        model.addAttribute("standings", standings);
        
        // Get current round and matches
        Round currentRound = tournamentService.getCurrentRound(tournamentId);
        model.addAttribute("currentRound", currentRound);
        
        if (currentRound != null) {
            List<Match> currentMatches = tournamentService.getRoundMatches(currentRound.getId());
            model.addAttribute("currentMatches", currentMatches);
        }
        
        // Get previous rounds
        if (tournament.isStarted()) {
            List<Round> allRounds = tournamentService.getTournamentRounds(tournamentId);
            List<Round> previousRounds = allRounds.stream()
                .filter(r -> !r.getRoundNumber().equals(tournament.getCurrentRound()))
                .collect(Collectors.toList());
                
            model.addAttribute("previousRounds", previousRounds);
            
            // Get matches for each previous round
            Map<Round, List<Match>> roundMatches = new HashMap<>();
            for (Round round : previousRounds) {
                roundMatches.put(round, tournamentService.getRoundMatches(round.getId()));
            }
            model.addAttribute("roundMatches", roundMatches);
        }
        
        // Check if current user is enrolled
        boolean isEnrolled = false;
        if (isAuthenticated) {
            String username = auth.getName();
            User user = userRepository.findByUsername(username)
                    .orElseThrow(() -> new IllegalStateException("User not found: " + username));
            isEnrolled = tournamentService.isUserEnrolled(tournamentId, user);
        }
        model.addAttribute("isEnrolled", isEnrolled);
        
        return "tournament-details";
    }

    @GetMapping("/my-tournaments")
    public String viewMyTournaments(Model model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !auth.isAuthenticated() || auth.getName().equals("anonymousUser")) {
            return "redirect:/login";
        }
        
        String username = auth.getName();
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new IllegalStateException("User not found: " + username));
        
        // Get tournaments where the user is enrolled
        List<Tournament> userTournaments = new java.util.ArrayList<>();
        List<Tournament> allTournaments = tournamentRepository.findAll();
        
        for (Tournament tournament : allTournaments) {
            if (tournamentService.isUserEnrolled(tournament.getId(), user)) {
                userTournaments.add(tournament);
            }
        }
        
        model.addAttribute("tournaments", userTournaments);
        
        // Since we know the user is enrolled in all displayed tournaments
        Map<Long, Boolean> enrollmentStatus = new HashMap<>();
        userTournaments.forEach(tournament -> {
            enrollmentStatus.put(tournament.getId(), true);
        });
        model.addAttribute("enrollmentStatus", enrollmentStatus);
        
        return "my-tournaments";
    }
} 