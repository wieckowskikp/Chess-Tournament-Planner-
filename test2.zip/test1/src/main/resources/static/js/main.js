// Main JavaScript file for Chess Tournament Planner

document.addEventListener('DOMContentLoaded', function() {
    console.log('Chess Tournament Planner loaded successfully');
    
    // Enable tooltips if Bootstrap is used
    if (typeof $ !== 'undefined' && typeof $.fn.tooltip !== 'undefined') {
        $('[data-toggle="tooltip"]').tooltip();
    }
    
    // Enable popovers if Bootstrap is used
    if (typeof $ !== 'undefined' && typeof $.fn.popover !== 'undefined') {
        $('[data-toggle="popover"]').popover();
    }
    
    // Form validation for registration
    const registrationForm = document.querySelector('form[action="/register"]');
    if (registrationForm) {
        registrationForm.addEventListener('submit', function(event) {
            const password = document.getElementById('password');
            if (password && password.value.length < 6) {
                event.preventDefault();
                alert('Password must be at least 6 characters long');
            }
        });
    }
}); 