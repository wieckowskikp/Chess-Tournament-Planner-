-- Insert sample tournaments if they don't exist
INSERT INTO tournaments (name, description, created_at)
SELECT 'Spring Chess Open', 'A beginner-friendly tournament for all chess enthusiasts', CURRENT_TIMESTAMP
WHERE NOT EXISTS (SELECT 1 FROM tournaments WHERE name = 'Spring Chess Open');

INSERT INTO tournaments (name, description, created_at)
SELECT 'Summer Championship', 'High-level competition for experienced players', CURRENT_TIMESTAMP
WHERE NOT EXISTS (SELECT 1 FROM tournaments WHERE name = 'Summer Championship');

INSERT INTO tournaments (name, description, created_at)
SELECT 'City Chess League', 'Weekly matches between local chess clubs', CURRENT_TIMESTAMP
WHERE NOT EXISTS (SELECT 1 FROM tournaments WHERE name = 'City Chess League');

-- Update existing tournaments that don't have a status to use CREATED status
UPDATE tournaments SET status = 'CREATED' WHERE status IS NULL;

-- Insert sample users if they don't exist
-- Note: These are sample users with unhashed passwords which is not secure for production
-- In a real application, passwords should be properly hashed
-- The application should handle password hashing correctly when users register normally

-- Check if any regular users exist
INSERT INTO users (username, email, password, first_name, last_name, role, elo, created_at, updated_at)
SELECT 'player1', 'player1@example.com', '$2a$10$ZLhnHxdpHETcxmtEStgpI.GBoA9XiYX4.tfG8.OJRLTv.7iu3.oZW', 'John', 'Smith', 'USER', 1200, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
WHERE NOT EXISTS (SELECT 1 FROM users WHERE role = 'USER' LIMIT 1);

INSERT INTO users (username, email, password, first_name, last_name, role, elo, created_at, updated_at)
SELECT 'player2', 'player2@example.com', '$2a$10$ZLhnHxdpHETcxmtEStgpI.GBoA9XiYX4.tfG8.OJRLTv.7iu3.oZW', 'Alice', 'Johnson', 'USER', 1350, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
WHERE NOT EXISTS (SELECT 1 FROM users WHERE username = 'player2');

INSERT INTO users (username, email, password, first_name, last_name, role, elo, created_at, updated_at)
SELECT 'player3', 'player3@example.com', '$2a$10$ZLhnHxdpHETcxmtEStgpI.GBoA9XiYX4.tfG8.OJRLTv.7iu3.oZW', 'Bob', 'Williams', 'USER', 1420, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
WHERE NOT EXISTS (SELECT 1 FROM users WHERE username = 'player3');

INSERT INTO users (username, email, password, first_name, last_name, role, elo, created_at, updated_at)
SELECT 'player4', 'player4@example.com', '$2a$10$ZLhnHxdpHETcxmtEStgpI.GBoA9XiYX4.tfG8.OJRLTv.7iu3.oZW', 'Carol', 'Brown', 'USER', 1280, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
WHERE NOT EXISTS (SELECT 1 FROM users WHERE username = 'player4');

INSERT INTO users (username, email, password, first_name, last_name, role, elo, created_at, updated_at)
SELECT 'player5', 'player5@example.com', '$2a$10$ZLhnHxdpHETcxmtEStgpI.GBoA9XiYX4.tfG8.OJRLTv.7iu3.oZW', 'David', 'Miller', 'USER', 1500, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
WHERE NOT EXISTS (SELECT 1 FROM users WHERE username = 'player5');

-- Only insert admin if it doesn't exist
INSERT INTO users (username, password, email, first_name, last_name, role, elo, created_at, updated_at)
SELECT 'admin', 
       '$2a$10$HhVPzwP8eK1LK7aKj7bTnOLV1jjwIEyT2Di9IyYVhFPJMGUSIq2fe', -- bcrypt encoded 'admin'
       'admin@gmail.com',
       'admin',
       'admin',
       'ADMIN',
       2400,
       NOW(),
       NOW()
WHERE NOT EXISTS (SELECT 1 FROM users WHERE username = 'admin'); 