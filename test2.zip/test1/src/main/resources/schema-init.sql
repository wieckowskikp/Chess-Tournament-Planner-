-- This is a safer schema initialization file that won't drop existing tables
-- Only run this manually when you need to initialize the schema

-- Create tables if they don't exist
CREATE TABLE IF NOT EXISTS tournaments (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    current_round INT DEFAULT 0,
    total_rounds INT,
    status VARCHAR(20) NOT NULL DEFAULT 'CREATED',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP NULL,
    winner_id BIGINT,
    FOREIGN KEY (winner_id) REFERENCES users(id)
);

-- Create tournament_participants table
CREATE TABLE IF NOT EXISTS tournament_participants (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    tournament_id BIGINT NOT NULL,
    joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (tournament_id) REFERENCES tournaments(id),
    UNIQUE (user_id, tournament_id)
);

-- Create rounds table
CREATE TABLE IF NOT EXISTS rounds (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    tournament_id BIGINT NOT NULL,
    round_number INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (tournament_id) REFERENCES tournaments(id),
    UNIQUE (tournament_id, round_number)
);

-- Create matches table
CREATE TABLE IF NOT EXISTS matches (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    round_id BIGINT NOT NULL,
    white_player_id BIGINT NOT NULL,
    black_player_id BIGINT NOT NULL,
    result VARCHAR(20) DEFAULT 'PENDING',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP NULL,
    FOREIGN KEY (round_id) REFERENCES rounds(id),
    FOREIGN KEY (white_player_id) REFERENCES users(id),
    FOREIGN KEY (black_player_id) REFERENCES users(id)
);

-- Create player_scores table
CREATE TABLE IF NOT EXISTS player_scores (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    tournament_id BIGINT NOT NULL,
    player_id BIGINT NOT NULL,
    score DOUBLE DEFAULT 0.0,
    matches_played INT DEFAULT 0,
    wins INT DEFAULT 0,
    draws INT DEFAULT 0,
    losses INT DEFAULT 0,
    FOREIGN KEY (tournament_id) REFERENCES tournaments(id),
    FOREIGN KEY (player_id) REFERENCES users(id),
    UNIQUE (tournament_id, player_id)
);

-- Update existing tournaments to have proper status if missing
UPDATE tournaments SET status = 'CREATED' WHERE status IS NULL; 