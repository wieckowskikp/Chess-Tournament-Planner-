-- WARNING: THIS FILE WILL DROP AND RECREATE ALL TABLES
-- IT IS INTENDED FOR DEVELOPMENT USE ONLY
-- DO NOT USE IN PRODUCTION!
-- The application is now configured to use schema-init.sql instead
-- which will not drop existing tables

-- First, create a backup of existing tournaments
CREATE TABLE IF NOT EXISTS tournaments_backup AS SELECT * FROM tournaments;

-- Drop tables in order (to avoid foreign key constraint issues)
DROP TABLE IF EXISTS player_scores;
DROP TABLE IF EXISTS matches;
DROP TABLE IF EXISTS rounds;
DROP TABLE IF EXISTS tournament_participants;
DROP TABLE IF EXISTS tournaments;

-- Recreate tournaments table with proper structure
CREATE TABLE tournaments (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    current_round INT DEFAULT 0,
    total_rounds INT,
    status VARCHAR(20) NOT NULL DEFAULT 'CREATED',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP NULL,
    winner_id BIGINT,
    FOREIGN KEY (winner_id) REFERENCES users(id)
);

-- Restore tournament data from backup
INSERT INTO tournaments (id, name, description, current_round, created_at)
SELECT id, name, description, current_round, created_at FROM tournaments_backup;

-- Update all restored tournaments to have CREATED status
UPDATE tournaments SET status = 'CREATED' WHERE status IS NULL;

-- Create tournament_participants table
CREATE TABLE tournament_participants (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    tournament_id BIGINT NOT NULL,
    joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (tournament_id) REFERENCES tournaments(id),
    UNIQUE (user_id, tournament_id)
);

-- Create rounds table
CREATE TABLE rounds (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    tournament_id BIGINT NOT NULL,
    round_number INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (tournament_id) REFERENCES tournaments(id),
    UNIQUE (tournament_id, round_number)
);

-- Create matches table
CREATE TABLE matches (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    round_id BIGINT NOT NULL,
    white_player_id BIGINT NOT NULL,
    black_player_id BIGINT NOT NULL,
    result VARCHAR(20) DEFAULT 'PENDING',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP NULL,
    FOREIGN KEY (round_id) REFERENCES rounds(id),
    FOREIGN KEY (white_player_id) REFERENCES users(id),
    FOREIGN KEY (black_player_id) REFERENCES users(id)
);

-- Create player_scores table
CREATE TABLE player_scores (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    tournament_id BIGINT NOT NULL,
    player_id BIGINT NOT NULL,
    score DOUBLE DEFAULT 0.0,
    matches_played INT DEFAULT 0,
    wins INT DEFAULT 0,
    draws INT DEFAULT 0,
    losses INT DEFAULT 0,
    FOREIGN KEY (tournament_id) REFERENCES tournaments(id),
    FOREIGN KEY (player_id) REFERENCES users(id),
    UNIQUE (tournament_id, player_id)
);

-- Drop the backup table
DROP TABLE IF EXISTS tournaments_backup; 