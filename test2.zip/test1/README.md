# Chess Tournament Planner

A web application for planning and managing chess tournaments.

## Technologies Used

- **Database**: MySQL
- **Backend**: Spring Framework + Hibernate
- **Frontend**: HTML, CSS, JavaScript with Thymeleaf templates

## Features

- User authentication (registration, login)
- Two user roles: Admin and User
- Basic user dashboard
- Admin panel for user and tournament management

## Setup and Installation

### Prerequisites

- Java 17
- Maven
- MySQL

### Database Setup

1. Create a MySQL database named `chess_tournament`
   ```sql
   CREATE DATABASE chess_tournament;
   ```

2. Configure your database username and password in `application.properties` if different from default:
   ```
   spring.datasource.username=root
   spring.datasource.password=your_password
   ```

### Running the Application

1. Clone the repository:
   ```
   git clone <repository-url>
   ```

2. Navigate to the project directory:
   ```
   cd chess-tournament-planner
   ```

3. Build the application:
   ```
   mvn clean install
   ```

4. Run the application:
   ```
   mvn spring-boot:run
   ```

5. Access the application in your browser:
   ```
   http://localhost:8080
   ```

### Admin User Setup

To create an admin user, you can use the registration form and then manually change the role in the database:

```sql
UPDATE users SET role = 'ADMIN' WHERE username = 'your_admin_username';
```

## Usage

- **Register**: Create a new user account
- **Login**: Access your dashboard
- **User Dashboard**: View available tournaments and personal information
- **Admin Panel**: Manage users and tournaments (accessible only to admin users)

## Future Enhancements

- Tournament creation and management
- Player matching algorithms
- Results tracking
- Rating systems 