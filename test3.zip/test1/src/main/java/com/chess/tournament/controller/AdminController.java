package com.chess.tournament.controller;

import com.chess.tournament.model.Match;
import com.chess.tournament.model.PlayerScore;
import com.chess.tournament.model.Round;
import com.chess.tournament.model.Tournament;
import com.chess.tournament.model.User;
import com.chess.tournament.repository.TournamentRepository;
import com.chess.tournament.repository.UserRepository;
import com.chess.tournament.service.TournamentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/admin")
public class AdminController {

    private final UserRepository userRepository;
    private final TournamentRepository tournamentRepository;
    private final TournamentService tournamentService;
    
    @Autowired
    public AdminController(UserRepository userRepository, 
                          TournamentRepository tournamentRepository,
                          TournamentService tournamentService) {
        this.userRepository = userRepository;
        this.tournamentRepository = tournamentRepository;
        this.tournamentService = tournamentService;
    }
    
    // User Management
    
    @GetMapping("/users")
    public String listUsers(Model model) {
        model.addAttribute("users", userRepository.findAll());
        return "admin/users/list";
    }
    
    @GetMapping("/users/{id}/edit")
    public String showEditUserForm(@PathVariable Long id, Model model) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid user ID: " + id));
        model.addAttribute("user", user);
        return "admin/users/edit";
    }
    
    @PostMapping("/users/{id}/update")
    public String updateUser(@PathVariable Long id, @ModelAttribute User userUpdate, 
                             RedirectAttributes redirectAttributes) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid user ID: " + id));
        
        // Update only the ELO field
        user.setElo(userUpdate.getElo());
        
        userRepository.save(user);
        redirectAttributes.addFlashAttribute("success", "User ELO updated successfully");
        return "redirect:/admin/users";
    }
    
    // Tournament Management
    
    @GetMapping("/tournaments")
    public String listTournaments(Model model) {
        model.addAttribute("tournaments", tournamentRepository.findAll());
        return "admin/tournaments/list";
    }
    
    @GetMapping("/tournaments/create")
    public String showCreateTournamentForm(Model model) {
        model.addAttribute("tournament", new Tournament());
        return "admin/tournaments/create";
    }
    
    @PostMapping("/tournaments/create")
    public String createTournament(@ModelAttribute Tournament tournament,
                                  RedirectAttributes redirectAttributes) {
        tournamentRepository.save(tournament);
        redirectAttributes.addFlashAttribute("success", "Tournament created successfully");
        return "redirect:/admin/tournaments";
    }
    
    @PostMapping("/tournaments/{id}/start")
    public String startTournament(@PathVariable("id") Long tournamentId,
                                RedirectAttributes redirectAttributes) {
        Tournament tournament = tournamentRepository.findById(tournamentId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid tournament ID: " + tournamentId));
        
        boolean success = tournamentService.startTournament(tournamentId);
        
        if (success) {
            redirectAttributes.addFlashAttribute("success", "Tournament started successfully");
        } else {
            redirectAttributes.addFlashAttribute("error", "Failed to start tournament. Make sure there are at least 2 participants.");
        }
        
        return "redirect:/tournaments/" + tournamentId + "/details";
    }
    
    @PostMapping("/tournaments/{tournamentId}/matches/{matchId}/result")
    public String updateMatchResult(@PathVariable("tournamentId") Long tournamentId,
                                   @PathVariable("matchId") Long matchId,
                                   @RequestParam("result") String result,
                                   RedirectAttributes redirectAttributes) {
        Match.Result matchResult;
        try {
            matchResult = Match.Result.valueOf(result);
        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("error", "Invalid match result");
            return "redirect:/tournaments/" + tournamentId + "/details";
        }
        
        boolean success = tournamentService.updateMatchResult(matchId, matchResult);
        
        if (success) {
            // Check if the tournament is now completed after this result
            Optional<Tournament> tournamentOpt = tournamentService.getTournamentById(tournamentId);
            if (tournamentOpt.isPresent() && tournamentOpt.get().isCompleted()) {
                redirectAttributes.addFlashAttribute("success", "Tournament completed successfully! The winner has been determined.");
            } else {
                redirectAttributes.addFlashAttribute("success", "Match result updated successfully");
            }
        } else {
            redirectAttributes.addFlashAttribute("error", "Failed to update match result");
        }
        
        return "redirect:/tournaments/" + tournamentId + "/details";
    }
    
    @PostMapping("/tournaments/{id}/next-round")
    public String advanceToNextRound(@PathVariable("id") Long tournamentId,
                                    RedirectAttributes redirectAttributes) {
        // Check if this is the last round
        boolean isLastRound = tournamentService.isLastRound(tournamentId);
        
        boolean success = tournamentService.advanceToNextRound(tournamentId);
        
        if (success) {
            if (isLastRound) {
                redirectAttributes.addFlashAttribute("success", "Tournament completed successfully! The winner has been determined.");
            } else {
                redirectAttributes.addFlashAttribute("success", "Advanced to next round");
            }
        } else {
            redirectAttributes.addFlashAttribute("error", "Failed to advance to next round. Make sure all matches are completed.");
        }
        
        return "redirect:/tournaments/" + tournamentId + "/details";
    }
    
    // Tournament Participant Management
    
    @PostMapping("/tournaments/{id}/add-participant")
    public String addParticipant(@PathVariable("id") Long tournamentId,
                                @RequestParam("userId") Long userId,
                                RedirectAttributes redirectAttributes) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid user ID: " + userId));
        
        boolean success = tournamentService.addParticipant(tournamentId, user);
        
        if (success) {
            redirectAttributes.addFlashAttribute("success", "Participant added successfully");
        } else {
            redirectAttributes.addFlashAttribute("error", "Failed to add participant. User may already be enrolled.");
        }
        
        return "redirect:/tournaments/" + tournamentId + "/details";
    }
    
    @PostMapping("/tournaments/{tournamentId}/remove-participant/{userId}")
    public String removeParticipant(@PathVariable("tournamentId") Long tournamentId,
                                   @PathVariable("userId") Long userId,
                                   RedirectAttributes redirectAttributes) {
        Tournament tournament = tournamentRepository.findById(tournamentId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid tournament ID: " + tournamentId));
        
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid user ID: " + userId));
        
        boolean removed = tournamentService.removeParticipant(tournamentId, user);
        
        if (removed) {
            redirectAttributes.addFlashAttribute("success", "Participant removed successfully");
        } else {
            redirectAttributes.addFlashAttribute("error", "Failed to remove participant");
        }
        
        return "redirect:/tournaments/" + tournamentId + "/details";
    }
    
    // Additional endpoint to load tournament details with admin-specific data
    @GetMapping("/tournaments/{id}/details")
    public String viewTournamentDetailsAdmin(@PathVariable("id") Long tournamentId, Model model) {
        // Get tournament
        Tournament tournament = tournamentRepository.findById(tournamentId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid tournament ID: " + tournamentId));
        model.addAttribute("tournament", tournament);
        
        // Get participants
        List<User> participants = tournamentService.getTournamentParticipants(tournamentId);
        model.addAttribute("participants", participants);
        
        // Get tournament standings
        List<PlayerScore> standings = tournamentService.getTournamentStandings(tournamentId);
        model.addAttribute("standings", standings);
        
        // Get current round and matches
        Round currentRound = tournamentService.getCurrentRound(tournamentId);
        model.addAttribute("currentRound", currentRound);
        
        if (currentRound != null) {
            List<Match> currentMatches = tournamentService.getRoundMatches(currentRound.getId());
            model.addAttribute("currentMatches", currentMatches);
        }
        
        // Get previous rounds
        if (tournament.isStarted()) {
            List<Round> allRounds = tournamentService.getTournamentRounds(tournamentId);
            List<Round> previousRounds = allRounds.stream()
                .filter(r -> !r.getRoundNumber().equals(tournament.getCurrentRound()))
                .collect(Collectors.toList());
                
            model.addAttribute("previousRounds", previousRounds);
            
            // Get matches for each previous round
            Map<Round, List<Match>> roundMatches = new HashMap<>();
            for (Round round : previousRounds) {
                roundMatches.put(round, tournamentService.getRoundMatches(round.getId()));
            }
            model.addAttribute("roundMatches", roundMatches);
        }
        
        // Get available users (users not enrolled in this tournament)
        List<User> allUsers = userRepository.findAll();
        List<User> availableUsers = allUsers.stream()
                .filter(user -> !tournamentService.isUserEnrolled(tournamentId, user))
                .collect(Collectors.toList());
        model.addAttribute("availableUsers", availableUsers);
        
        return "tournament-details";
    }

    @PostMapping("/tournaments/{id}/delete")
    public String removeTournament(@PathVariable("id") Long tournamentId,
                                  RedirectAttributes redirectAttributes) {
        try {
            tournamentService.deleteTournament(tournamentId);
            redirectAttributes.addFlashAttribute("success", "Tournament successfully deleted");
            return "redirect:/admin/tournaments";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Failed to delete tournament: " + e.getMessage());
            return "redirect:/tournaments/" + tournamentId + "/details";
        }
    }
} 